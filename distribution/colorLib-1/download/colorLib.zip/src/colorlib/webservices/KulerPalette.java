package colorlib.webservices;

import processing.core.*;
import colorlib.Palette;

public class KulerPalette extends Palette {

	public KulerPalette( final PApplet parent )
	{
		super( parent ); // call Palette()
	}
}
