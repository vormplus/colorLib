package colorlib.webservices;

import processing.core.*;
import colorlib.Palette;

public class ColourLoversPalette extends Palette {

	public ColourLoversPalette( final PApplet parent )
	{
		super( parent ); // call Palette()
	}
}
