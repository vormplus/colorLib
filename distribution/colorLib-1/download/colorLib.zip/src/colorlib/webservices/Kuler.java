package colorlib.webservices;

import processing.core.*;

public class Kuler {

	protected PApplet p;
	
	public Kuler( final PApplet parent )
	{
		p = parent;
		
	}
}
