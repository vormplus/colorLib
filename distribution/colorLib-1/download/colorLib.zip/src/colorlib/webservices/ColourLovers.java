package colorlib.webservices;

import processing.core.*;

public class ColourLovers {

	protected PApplet p;
	
	public ColourLovers( final PApplet parent )
	{
		p = parent;
		
	}
	
}