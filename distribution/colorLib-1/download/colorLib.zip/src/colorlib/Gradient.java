package colorlib;

import processing.core.*;

public class Gradient extends Palette {

	public Gradient( final PApplet parent )
	{
		super( parent ); // call Palette()
	}
}
